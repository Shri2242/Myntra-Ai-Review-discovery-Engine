import { AI_CONFIG } from '../../config.js';

// eslint-disable-next-line @typescript-eslint/no-explicit-any
type Pipeline = any;

/**
 * Local embedding generator using @xenova/transformers.
 * Runs entirely on the CPU — no API key or network calls needed.
 * Uses the Xenova/all-MiniLM-L6-v2 model (384-dim vectors).
 */
export class LocalEmbedder {
  private pipeline: Pipeline | null = null;
  private initPromise: Promise<Pipeline> | null = null;
  private model: string;

  constructor(model?: string) {
    this.model = model || AI_CONFIG.EMBEDDING_MODEL;
  }

  /**
   * Lazy-load the model pipeline on first call (singleton).
   * Subsequent calls reuse the same loaded model.
   */
  private async getPipeline(): Promise<Pipeline> {
    if (this.pipeline) return this.pipeline;

    if (!this.initPromise) {
      this.initPromise = (async () => {
        // Dynamic import to avoid loading the heavy module at startup
        const { pipeline } = await import('@xenova/transformers');
        this.pipeline = await pipeline('feature-extraction', this.model);
        return this.pipeline;
      })();
    }

    return this.initPromise;
  }

  /**
   * Generate embeddings for an array of texts.
   * Processes in batches of EMBEDDING_BATCH_SIZE.
   */
  async embed(texts: string[]): Promise<{
    embeddings: number[][];
    model: string;
    usage: { totalTokens: number };
  }> {
    const pipe = await this.getPipeline();
    const batchSize = AI_CONFIG.EMBEDDING_BATCH_SIZE;
    const allEmbeddings: number[][] = [];

    for (let i = 0; i < texts.length; i += batchSize) {
      const batch = texts.slice(i, i + batchSize);
      const output = await pipe(batch, { pooling: 'mean', normalize: true });

      // output.tolist() returns number[][] — one embedding per text
      const batchEmbeddings: number[][] = output.tolist();
      allEmbeddings.push(...batchEmbeddings);
    }

    return {
      embeddings: allEmbeddings,
      model: this.model,
      // Local model — approximate token count as word count * 1.3
      usage: {
        totalTokens: texts.reduce((sum, t) => sum + Math.ceil(t.split(/\s+/).length * 1.3), 0),
      },
    };
  }
}
